Page({
  data: {
    movieList: [{
      create_time: 1532519754589,
      title: '海边随拍',
      src: 'https://vdept3.bdstatic.com/mda-rae2i5f3jc378jd6/sc/cae_h264/1736905797476756930/mda-rae2i5f3jc378jd6.mp4?v_from_s=hkapp-haokan-hbf&auth_key=1745318642-0-0-fa3ba06e4f23f2e13ea58a1f84af8e7c&bcevod_channel=searchbox_feed&pd=1&cr=2&cd=0&pt=3&logid=2642867002&vid=12891016384387683794&klogid=2642867002&abtest='

    }, {
      create_time: 1532519777690,
      title: '勿忘心安',
      src: 'https://vdept3.bdstatic.com/mda-rae2i5f3jc378jd6/sc/cae_h264/1736905797476756930/mda-rae2i5f3jc378jd6.mp4?v_from_s=hkapp-haokan-hbf&auth_key=1745318642-0-0-fa3ba06e4f23f2e13ea58a1f84af8e7c&bcevod_channel=searchbox_feed&pd=1&cr=2&cd=0&pt=3&logid=2642867002&vid=12891016384387683794&klogid=2642867002&abtest='

    }, {
      create_time: 1532519734589,
      title: '点滴记忆',
      src: 'https://vdept3.bdstatic.com/mda-rae2i5f3jc378jd6/sc/cae_h264/1736905797476756930/mda-rae2i5f3jc378jd6.mp4?v_from_s=hkapp-haokan-hbf&auth_key=1745318642-0-0-fa3ba06e4f23f2e13ea58a1f84af8e7c&bcevod_channel=searchbox_feed&pd=1&cr=2&cd=0&pt=3&logid=2642867002&vid=12891016384387683794&klogid=2642867002&abtest='
    }]
  }
})