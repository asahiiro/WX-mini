Page({
  data: {
    imgUrls: [
      '/images/timg0.jpg',
      '/images/timg2.jpg',
      '/images/timg3.jpg',
      '/images/timg4.jpg'
    ]
  }
})