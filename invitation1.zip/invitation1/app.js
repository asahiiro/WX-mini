App({
	globalData:{
	  hasSubscribeMessage: ''
  }
})
 